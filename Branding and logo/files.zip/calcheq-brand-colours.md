# CalCheq Brand Colour Specification

## Logo Colour Palette

### Icon — Arc Gradient (Dark Background Version)
The main gauge arc uses a 4-stop gradient that sweeps from left to right:

| Position | Hex | Opacity | RGB | Usage |
|----------|-----|---------|-----|-------|
| 0% | `#0D2250` | 0% (transparent) | 13, 34, 80 | Gradient fade-in point |
| 20% | `#2E8ED8` | 70% | 46, 142, 216 | Mid-blue start |
| 60% | `#1FCAD8` | 100% | 31, 202, 216 | Teal-cyan |
| 100% | `#3FF2DC` | 100% | 63, 242, 220 | Bright mint-cyan endpoint |

### Icon — Arc Gradient (Light Background Version)

| Position | Hex | Opacity | RGB | Usage |
|----------|-----|---------|-----|-------|
| 0% | `#D4DCF0` | 80% | 212, 220, 240 | Light blue fade-in |
| 20% | `#1864C8` | 50% | 24, 100, 200 | Muted electric blue |
| 50% | `#1864C8` | 100% | 24, 100, 200 | Electric blue core |
| 80% | `#0B9EAA` | 100% | 11, 158, 170 | Teal |
| 100% | `#0E8094` | 100% | 14, 128, 148 | Deep teal endpoint |

### Icon — Checkmark Gradient (Dark Background Version)

| Position | Hex | RGB | Usage |
|----------|-----|-----|-------|
| 0% | `#6DFBB0` | 109, 251, 176 | Bright mint highlight |
| 100% | `#0F8A4A` | 15, 138, 74 | Deep forest green shadow |

### Icon — Checkmark Gradient (Light Background Version)

| Position | Hex | RGB | Usage |
|----------|-----|-----|-------|
| 0% | `#2ECC7A` | 46, 204, 122 | Success green |
| 100% | `#0E7048` | 14, 112, 72 | Deep green shadow |

### Wordmark — "Cheq" Gradient (Dark Background)

| Position | Hex | RGB |
|----------|-----|-----|
| 0% | `#2E8ED8` | 46, 142, 216 |
| 100% | `#3FF2DC` | 63, 242, 220 |

### Wordmark — "Cheq" Gradient (Light Background)

| Position | Hex | RGB |
|----------|-----|-----|
| 0% | `#1864C8` | 24, 100, 200 |
| 100% | `#0B9EAA` | 11, 158, 170 |

### Endpoint Accent Dots
- Bright cap (dark bg): `#3FF2DC` with `#FFFFFF` centre pin
- Bright cap (light bg): `#0E8094` with `#FFFFFF` centre pin

### Other Logo Elements
- "Cal" wordmark on dark: `#FFFFFF`
- "Cal" wordmark on light: `#0B1628`
- Divider line on dark: `#1A2D50` at 0.5px
- Divider line on light: `#D4DCF0` at 0.5px
- Tagline on dark: `#4A7AA8`
- Tagline on light: `#5A7898`

---

## Full Brand Palette

### Primary Colours

| Name | Hex | RGB | Use Case |
|------|-----|-----|----------|
| Deep Navy | `#0B1628` | 11, 22, 40 | Primary brand colour, body backgrounds, headings on light |
| Midnight Navy | `#050B1C` | 5, 11, 28 | Hero backgrounds, dark mode base |
| Indigo Navy | `#0A1840` | 10, 24, 64 | Secondary dark surfaces |
| Electric Blue | `#1864C8` | 24, 100, 200 | Primary brand accent, CTAs, links |
| Mid Blue | `#2E8ED8` | 46, 142, 216 | Gradient transitions, UI accents |
| Cyan Teal | `#1FCAD8` | 31, 202, 216 | Logo mid-tone, highlights |
| Bright Mint-Cyan | `#3FF2DC` | 63, 242, 220 | Logo endpoint, glow accents |
| Deep Teal | `#0B9EAA` | 11, 158, 170 | Light-mode teal variant |

### Neutrals

| Name | Hex | RGB | Use Case |
|------|-----|-----|----------|
| White | `#FFFFFF` | 255, 255, 255 | Logo text on dark, primary surfaces |
| Off-White | `#F4F8FF` | 244, 248, 255 | Page backgrounds |
| Light Grey | `#F4F7FB` | 244, 247, 251 | Card backgrounds on light |
| Border Light | `#D4DCF0` | 212, 220, 240 | Divider lines on light |
| Border Dark | `#1A2D50` | 26, 45, 80 | Divider lines on dark |
| Secondary Text | `#4A7AA8` | 74, 122, 168 | Tagline on dark |
| Muted Text | `#5A7898` | 90, 120, 152 | Tagline on light, body subtext |
| Medium Grey | `#8BA8CC` | 139, 168, 204 | Secondary UI text |

### Semantic / Status Colours

| Name | Hex | RGB | Use Case |
|------|-----|-----|----------|
| Success Green | `#22D67A` | 34, 214, 122 | Pass states, check marks, positive status |
| Bright Mint | `#6DFBB0` | 109, 251, 176 | Check highlight gradient top |
| Deep Green | `#0F8A4A` | 15, 138, 74 | Check shadow gradient bottom |
| Alert Amber | `#F59E0B` | 245, 158, 11 | Warnings, due-soon instruments |
| Critical Red | `#EF4444` | 239, 68, 68 | Overdue alerts, failures, critical drift |

---

## Typography

### Primary Typeface
**Inter** (web) — fallback to **SF Pro Display** (macOS/iOS), then system-ui

Full CSS stack:
```
font-family: 'Inter', 'SF Pro Display', -apple-system, BlinkMacSystemFont, system-ui, sans-serif;
```

Get Inter free from: https://fonts.google.com/specimen/Inter

### Logo Wordmark Specifications
- "Cal" — Font weight: `700` (Bold)
- "Cheq" — Font weight: `300` (Light) with gradient fill
- Letter-spacing: `-1px` (tight, premium)
- Size: `36px` for horizontal lockup

### Tagline
- Font weight: `500` (Medium)
- Size: `8px` (in horizontal lockup), scales proportionally
- Letter-spacing: `2.5px` (wide)
- Case: UPPERCASE
- Content: "CALIBRATION · INTELLIGENCE · RELIABILITY"

---

## Usage Guidelines

### Minimum Clear Space
Maintain padding equal to the height of the "C" in CalCheq on all sides around the logo.

### Minimum Size
- Horizontal lockup: 160px wide minimum
- Icon only: 20px minimum
- Below 20px, consider using a simplified favicon version

### Do Not
- Stretch, skew, or rotate the logo
- Change the gradient directions or colours
- Place the dark-background version on light backgrounds (and vice versa)
- Recreate the wordmark in a different typeface
- Use the tagline without the logo
- Place the logo over busy imagery without a solid underlay

---

## Quick Reference — Most Used Colours

For fast reference when building the website:

```css
/* Brand core */
--navy-deep: #0B1628;
--navy-midnight: #050B1C;
--blue-electric: #1864C8;
--blue-mid: #2E8ED8;
--teal-cyan: #1FCAD8;
--mint-cyan: #3FF2DC;
--teal-deep: #0B9EAA;

/* Status */
--success: #22D67A;
--warning: #F59E0B;
--danger: #EF4444;

/* Neutrals */
--white: #FFFFFF;
--text-muted: #5A7898;
--border-light: #D4DCF0;
--border-dark: #1A2D50;
```
